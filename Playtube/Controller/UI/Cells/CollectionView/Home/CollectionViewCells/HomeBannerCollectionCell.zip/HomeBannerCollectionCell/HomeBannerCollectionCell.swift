//
//  HomeBannerCollectionCell.swift
//  Playtube
//
//  Created by Moghees on 26/12/2022.
//  Copyright © 2022 ScriptSun. All rights reserved.
//

import UIKit

class HomeBannerCollectionCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
